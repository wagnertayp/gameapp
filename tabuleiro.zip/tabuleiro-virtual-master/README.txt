Icones: http://www.flaticon.com
<div>Icons made by <a href="http://www.flaticon.com/authors/icomoon" title="Icomoon">Icomoon</a> from <a href="http://www.flaticon.com" title="Flaticon">www.flaticon.com</a>             is licensed by <a href="http://creativecommons.org/licenses/by/3.0/" title="Creative Commons BY 3.0">CC BY 3.0</a></div>
elf_fighter: Imagem de <a href="https://pixabay.com/pt/users/anaterate-2348028/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3333173">Wolfgang Eckert</a> por <a href="https://pixabay.com/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3333173">Pixabay</a>
human_bard: Imagem de <a href="https://pixabay.com/pt/users/anaterate-2348028/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3276861">Wolfgang Eckert</a> por <a href="https://pixabay.com/pt/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3276861">Pixabay</a>
icon_melee: Imagem de <a href="https://pixabay.com/pt/users/Clker-Free-Vector-Images-3736/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=311733">Clker-Free-Vector-Images</a> por <a href="https://pixabay.com/pt/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=311733">Pixabay</a>
bump maps: https://3dtextures.me/
icon_sling: Imagem de <a href="https://delapouite.com/">Delapouite</a>, inverted colors.
icon roll skill: https://imgur.com/a/KBQkz
megaraptor: <a href='https://en.wikipedia.org/wiki/Megaraptor#/media/File:Megaraptor_namunhuaiquii.jpg'>Alexander Thomas Lovrgrove as per CC BY SA 4.0</a>
som steel:<a href='https://freesound.org/people/Erdie/sounds/27858/'>https://freesound.org/people/Erdie/sounds/27858/</a>
som miss: https://freesound.org/people/CGEffex/sounds/93081/
som punch: https://freesound.org/people/ztrees1/sounds/134934/
som whip: https://freesound.org/people/CGEffex/sounds/93100/
som glass_break: https://freesound.org/people/unfa/sounds/221528/
som spiked_chain: https://freesound.org/people/daveincamas/sounds/44076/
som hideous_laughter: https://freesound.org/people/RaspberryTickle/sounds/203231/
som pistol: https://freesound.org/people/schots/sounds/382735/
som landslide: https://freesound.org/people/tayingalive/sounds/442552/

terrain_foliage_coarse.png: CC BY-SA 3.0 -- Heath Rezabek -- Vessel CC -- http://vessel.cc
swarm_spider: Spider made by Tuomo Untinen.
