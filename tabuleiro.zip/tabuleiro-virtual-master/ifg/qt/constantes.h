#ifndef IFG_QT_CONSTANTES_H
#define IFG_QT_CONSTANTES_H

#define DIR_TEXTURAS "texturas"
#define DIR_TEXTURAS_LOCAIS "texturas_locais"
#define FILTRO_IMAGENS "Imagens (*.png *.gif *.jpg *.bmp)"

#endif
