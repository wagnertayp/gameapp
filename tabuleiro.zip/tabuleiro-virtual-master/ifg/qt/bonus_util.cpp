#include "ifg/qt/bonus_util.h"

// Este arquivo é apenas para evitar linker errors com Q_OBJECT em .h puros.

namespace ifg {
namespace qt {

ModeloBonus::~ModeloBonus() {}
TipoBonusDelegate::~TipoBonusDelegate() {}

}  // namespace qt
}  // namespace ifg
