#!/bin/bash

zip -r texturas_modelos_tabuleiros-$(date +%Y%m%d).zip tabuleiros_salvos modelos3d texturas sons fontes/*ttf


