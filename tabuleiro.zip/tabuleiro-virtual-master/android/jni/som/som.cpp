#include "som/som.h"

namespace som {

void Inicia(const ent::OpcoesProto& opcoes) {}
void Toca(const std::string& nome) {}
void Finaliza() {}

}  // namespace som

